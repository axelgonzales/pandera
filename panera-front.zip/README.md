# Sistema Panera - Front

Frontend para el Sistema Panera

### Instalar Angular CLI:

Posicionarse dentro de la carpeta donde esta el proyecto y luego desde la consola ejecutar lo siguiente

```bash
$ npm install -g @angular/cli@latest
```

Seguidamente ejecutar el siguiente comando para poder descargar las librerias del proyecto

```bash
$ npm install
```

Finalmente para ejecutar el proyecto debemos ejecutar 

```bash
$ ng serve
```
