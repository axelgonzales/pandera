export const environment = {
  production: false,
  API_URL: 'http://localhost:9091/panera-back',
  GENKEY_URL: 'http://localhost:3000',
  DEBUG: true,
  defaultLang: 'es',
};