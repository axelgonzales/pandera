export const environment = {
  production: true,
  API_URL: 'http://panera-api.vegosac.com',
  GENKEY_URL: '',
  defaultLang: 'es',
};