export class PermisoResponse {
    public id: number;
    public idPadre: number;
    public nombre: string;
    public descripcion: string;
    public url: string;
    public inPadre: string;
}
