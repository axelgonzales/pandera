export class LoginRequest {
    public usuario: string;
    public contrasena: string;
    [key: string]: string | object | undefined;
}
