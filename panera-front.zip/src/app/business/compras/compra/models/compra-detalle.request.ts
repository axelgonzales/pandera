export class CompraDetalleRequest {
    public id: number;
    public idInsumo: number;
    public idMarca: number;
    public igv: number;
    public contenido: number;
    public cantidad: number;
    public precioUnitario: number;
    public precioTotal: number;
    public activo: string;
}
