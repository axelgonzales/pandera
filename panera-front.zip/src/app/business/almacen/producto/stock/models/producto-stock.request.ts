export class ProductoStockRequest {
  public id: number;
  public idAlmacen: number;
  public idPedido: number;
  public idTipoCategoria: number;
  public idCategoria: number;
  public numPedido: string;
}

