export class ProductoSalidaDetalleRequest {
    public id: number;
    public idSalida: number;
    public idProducto: number;
    public cantidad: number;
    public precio: number;
}
