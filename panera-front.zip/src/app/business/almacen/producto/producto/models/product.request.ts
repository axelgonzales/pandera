export class ProductoRequest {
    public id: number;
    public nombre: string;
    public descripcion: string;
    public idTipoCategoria: number;
    public idCategoria: number;
    public idFamilia: number;
    public idSubFamilia: number;
    public idMedida: number;
}
