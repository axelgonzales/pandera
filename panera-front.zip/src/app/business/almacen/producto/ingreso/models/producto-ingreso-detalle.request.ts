export class ProductoIngresoDetalleRequest {

}
