export class ProductoIngresoDetalleResponse {
    public id: number;
    public idTipoCategoria: number;
    public nomTipoCategoria: string;
    public idCategoria: number;
    public nomCategoria: string;
    public idProducto: number;
    public nomProducto: string;
    public precio: number;
    public cantidad: number;
    public medida: string;
}
