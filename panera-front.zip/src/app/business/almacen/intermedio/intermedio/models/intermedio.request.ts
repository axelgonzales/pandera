export class IntermedioRequest {
    public id: number;
    public nombre = '';
    public descripcion: string;
    public idMedida: number;
    public minimo: number;
}
