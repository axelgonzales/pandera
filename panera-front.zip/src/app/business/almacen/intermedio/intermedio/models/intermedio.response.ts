export class IntermedioResponse {
    public id = 0;
    public nombre = '';
    public descripcion: string;
    public idMedida = 0;
    public nomMedida: string;
    public minimo = 0;
    public activo = '0';
}
