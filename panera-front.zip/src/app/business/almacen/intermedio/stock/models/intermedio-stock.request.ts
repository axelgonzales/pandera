export class IntermedioStockRequest {
    public idAlmacen: number;
    public idPedido: number;
    public numPedido: string;
}
