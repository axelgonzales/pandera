export class IntermedioStockResponse {
    public idAlmacen: number;
    public nomAlmacen: string;
    public idPedido: number;
    public numPedido: string;
    public idIntermedio: number;
    public nomIntermedio: string;
    public cantidad: number;
    public costo: number;
}
