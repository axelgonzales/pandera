export class IntermedioSalidaDetalleResponse {
    public id: number;
    public idIntermedio: number;
    public nomIntermedio: string;
    public precio: number;
    public cantidad: number;
    public medida: string;
}
