export class IntermedioSalidaDetalleRequest {

}
