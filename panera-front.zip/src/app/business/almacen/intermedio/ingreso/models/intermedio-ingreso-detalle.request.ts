export class IntermedioIngresoDetalleRequest {

}
