export class IntermedioIngresoRequest {
    public id: number;
    public idTipo: number;
    public idAlmacen: number;
    public idEstado: number;
    public numPedido: string;
    public observacion: string;
    public fecha: string;
}
