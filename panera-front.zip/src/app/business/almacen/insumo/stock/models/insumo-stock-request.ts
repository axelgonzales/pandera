export class InsumoStockRequest {
    public id: number;
    public idInsumo = 0;
    public idProveedor = 0;
    public idMarca = 0;
}
