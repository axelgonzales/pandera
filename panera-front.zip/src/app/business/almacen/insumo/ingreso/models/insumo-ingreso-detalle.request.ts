export class InsumoIngresoDetalleRequest {
    public id: number;
    public idInsumo: number;
    public idProveedor: number;
    public idMarca: number;
    public cantidad: number;
    public cantidadReal: number;
    public precio: number;
    public activo: string;
}
