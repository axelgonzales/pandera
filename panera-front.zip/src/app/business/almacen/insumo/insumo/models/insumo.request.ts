export class InsumoRequest {
    public id: number;
    public nombre = '';
    public descripcion: string;
    public idCategoria: number;
    public idMedida: number;
    public minimo: number;
}