export class InsumoSalidaDetalleResponse {
    public id: number;
    public idTipoCategoria: number;
    public nomTipoCategoria: string;
    public idCategoria: number;
    public nomCategoria: string;
    public idInsumo: number;
    public nomInsumo: string;
    public precio: number;
    public cantidad: number;
    public medida: string;
}
