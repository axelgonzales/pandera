export class SubFamiliaRequest {
    public id: number;
    public nombre: string;
    public descripcion: string;
}
