export class SubFamiliaResponse {
    public id: number;
    public nombre: string;
    public descripcion: string;
}
