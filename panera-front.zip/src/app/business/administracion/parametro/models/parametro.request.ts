export class ParametroRequest {
    public id: number;
    public nombre = '';
    public descripcion: string;
    public idTipo: number;
}
