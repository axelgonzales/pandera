export class ParametroResponse {
    public id = 0;
    public nombre = '';
    public idTipo = 0;
    public nomTipo: string;
    public descripcion: string;
}
