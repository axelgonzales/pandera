export class TipoCategoriaRequest {
    public id: number;
    public nombre = '';
    public descripcion: string;
    public tipo: string;
}
