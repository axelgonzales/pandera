export class TipoCategoriaResponse {
    public id: number;
    public nombre: string;
    public descripcion: string;
    public tipo: string;
    public nomTipo: string;
}
