export class MarcaRequest {
    public id: number;
    public nombre = '';
    public descripcion: string;
}
