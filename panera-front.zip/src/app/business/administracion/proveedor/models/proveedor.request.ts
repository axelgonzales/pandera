export class ProveedorRequest {
    public id: number;
    public ruc: string;
    public razonSocial: string;
    public direccion: string;
}