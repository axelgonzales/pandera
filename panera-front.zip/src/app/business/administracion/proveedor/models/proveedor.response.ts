export class ProveedorResponse {
    public id: number;
    public razonSocial: string;
    public ruc: string;
    public direccion: string;
}
