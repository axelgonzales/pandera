export class TipoParametroResponse {
    public id: number;
    public nombre: string;
    public descripcion: string;
}