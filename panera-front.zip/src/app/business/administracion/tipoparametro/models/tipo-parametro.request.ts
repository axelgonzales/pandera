export class TipoParametroRequest {
    public nombre: string;
}