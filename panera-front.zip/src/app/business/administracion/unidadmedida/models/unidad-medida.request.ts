export class UnidadMedidaRequest {
    public nombre = '';
}
