export class UnidadMedidaResponse {
    public id: number;
    public nombre: string;
    public abreviatura: string;
    public descripcion: string;
}
