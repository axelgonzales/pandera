export class TiendaResponse {
    public id: number;
    public nombre: string;
    public ruc: string;
    public direccion: string;
}
