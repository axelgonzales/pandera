export class TiendaRequest {
    public id: number;
    public nombre = '';
    public ruc = '';
    public direccion: string;
}
