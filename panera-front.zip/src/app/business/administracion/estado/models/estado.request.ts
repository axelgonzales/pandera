export class EstadoRequest {
    public idTipo: number;
}
