export class FamiliaRequest {
    public id: number;
    public nombre: string;
    public descripcion: string;
}
