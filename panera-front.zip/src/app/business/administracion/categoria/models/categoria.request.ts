export class CategoriaRequest {
    public id: number;
    public idTipo: number;
    public nombre: string;
    public descripcion: string;
}
