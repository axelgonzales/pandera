export class CategoriaResponse {
    public id: number;
    public nombre: string;
    public descripcion: string;
    public idTipo: number;
    public nomTipo: string;
}
