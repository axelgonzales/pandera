export class DevolucionDetalleResponse {
    public id: number;
    public idDevolucion: number;
    public idPedido: number;
    public numPedido: string;
    public idProducto: number;
    public nomProducto: string;
    public idEstado: number;
    public nomEstado: string;
    public numDevolucion: string;
    public fechaDevolucion: string;
    public cantidad: number;
    public activo: string;
}
