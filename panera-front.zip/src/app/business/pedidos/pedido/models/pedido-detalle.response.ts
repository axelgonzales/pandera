export class PedidoDetalleResponse {
    public id: number;
    public idProducto: number;
    public nomProducto: string;
    public idCategoria: number;
    public nomCategoria: string;
    public idTipoCategoria: number;
    public nomTipoCategoria: string;
    public idEstado: number;
    public nomEstado: string;
    public idMedida: number;
    public nomMedida: string;
    public cantidad: number;
    public descripcion: string;
    public activo: string;
}
