export class PedidoMedidaResponse {
    public id: number;
    public nombre: string;
    public valor: number;
}
