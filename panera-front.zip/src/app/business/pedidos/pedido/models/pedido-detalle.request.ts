export class PedidoDetalleRequest {
    public id: number;
    public idProducto: number;
    public cantidad: number;
    public idMedida: number;
    public descripcion: string;
    public activo: string;
}
