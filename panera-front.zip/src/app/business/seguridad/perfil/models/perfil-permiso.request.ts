export class PerfilPermisoRequest {
    public id: number;
    public idPermiso: number;
    public nomPermiso: string;
    public url: string;
    public inPadre: string;
    public activo: string;
}
