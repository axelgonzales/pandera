export class PerfilPermisoResponse {
    public id: number;
    public idPadre: number;
    public idPermiso: number;
    public nomPermiso: string;
    public url: string;
    public inPadre: string;
    public activo: string;
}
