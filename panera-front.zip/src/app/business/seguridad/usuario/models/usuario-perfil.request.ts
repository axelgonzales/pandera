export class UsuarioPerfilRequest {
    public id: number;
    public idPerfil: number;
    public activo: string;
}
