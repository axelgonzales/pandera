export class UsuarioPerfilResponse {
    public id: number;
    public idPerfil: number;
    public nomPerfil: string;
    public activo: string;
}
