export class PermisoRequest {
    public nombre = '';
}
