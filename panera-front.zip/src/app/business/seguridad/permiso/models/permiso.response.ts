export class PermisoResponse {
    public id: number;
    public nombre: string;
    public descripcion: string;
}
