export class RecetaDetalleRequest {
    public id: number;
    public idInsumo: number;
    public idIntermedio: number;
    public cantidad: number;
    public activo: string;
}
