export class RecetaDetalleResponse {
    public id: number;
    public nomIngrediente: string;
    public nomTipoCategoria: string;
    public nomCategoria: string;
    public idInsumo: number;
    public nomInsumo: string;
    public idIntermedio: number;
    public nomIntermedio: string;
    public cantidad: number;
    public idMedida: number;
    public nomMedida: string;
}
