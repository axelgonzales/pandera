
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';

@Injectable()
export class HomeService {

    constructor(private http: HttpClient) {

    }

    validarSesion() {

    }

    cerrarSesion() {
        
    }

}