export class PaneraTipoParametro {

    public static ID_MODALIDAD_DE_PAGO = 1;
    public static ID_DOCUMENTOS_DE_COMPRA = 2;
    public static ID_CONDICIONES_DE_PAGO = 3;
    public static ID_TIPOS_INGRESO_ALMACEN = 4;
    public static ID_TIPOS_SALIDA_ALMACEN = 5;
    public static ID_TIPOS_DE_COMPRAS = 6;
    public static ID_TIPOS_DE_RECETAS = 7;
    public static ID_TIPOS_DE_PEDIDOS = 8;

}
