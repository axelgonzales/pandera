import { Injectable } from '@angular/core';

@Injectable()
export class PaneraParametro {

    public static ID_TIPO_RECETA_PRODUCTO = 13;
    public static ID_TIPO_RECETA_INTERMEDIO = 14;
    public static ID_TIPO_PEDIDO_NORMAL = 15;
    public static ID_TIPO_PEDIDO_ESPECIAL = 16;

}
