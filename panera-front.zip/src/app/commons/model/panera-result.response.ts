export class PaneraResultResponse<Object>{

    public success : boolean;
    public message : string;
    public result: Object;

}